# Zygisk Mod Menu Template
Mod Menu template that injects at runtime for unity games. This will bypass most common checks as it doesn't modify the game's APK file.

yeah now this is detected in most games, you might be lucky tho

This repository also uses cURL and ImGui (duh)Remember to change module.gradle before publishing,
Main code lives in hook.cpp

# Build and Installation
Android Studio is required: https://developer.android.com/studio  <br />
Use Android Studio to run the gradle task :module:assembleRelease to compile, the zip package will be generated in the out folder

# Credits
Perfare - https://github.com/Perfare/Zygisk-Il2CppDumper <br />
springmusk026 - https://github.com/springmusk026/ImGui-Unity-With-Layout <br />
jmpews - https://github.com/jmpews/Dobby <br />
Polarmods - https://github.com/Polarmods/PolarImGui <br />
oobbb - https://github.com/oobbb/Zygisk-Inject-ImGui <br />
